from django.db import models

# Create your models here.
class Dojos(models.Model):
    name=models.CharField(max_length=20)
    city=models.CharField(max_length=20)
    state=models.CharField(max_length=20)
    desc=models.CharField(max_length=40)
    created_at=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now=True)
    
class Ninjas(models.Model):
    first_name=models.CharField(max_length=20)
    last_name=models.CharField(max_length=20)
    dojo=models.ForeignKey(Dojos,related_name='ninjas',on_delete=models.CASCADE)
    
        